<?php
$servername = "sql12.freesqldatabase.com";
$username = "sql12658209";
$password = "1lwtJTZjGN";
$database = "sql12658209";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Die if connection was not successful
?>




<!--
Host: sql12.freesqldatabase.com
Database name: sql12658209
Database user: sql12658209
Database password: 1lwtJTZjGN
Port number: 3306
 -->

